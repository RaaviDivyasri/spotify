function createAudioPlayer() {
    const audioPlayer = document.createElement('audio');
    audioPlayer.id = 'audioPlayer';
    audioPlayer.controls = true;
    const audioSource = document.createElement('source');
    audioSource.src = 'your_audio_file.mp3';
    audioSource.type = 'audio/mp3';
    audioPlayer.appendChild(audioSource);
    document.body.appendChild(audioPlayer);
    audioPlayer.play();
}
createAudioPlayer();
